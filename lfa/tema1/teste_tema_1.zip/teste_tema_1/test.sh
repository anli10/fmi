#!/bin/bash

TESTNO=9




cp $1 "tema.cpp"
make

TESTS=(1 2 3 4 7 8)

for i in ${TESTS[*]}
do
	./tema "t0${i}.in" > "t0${i}.res"
	cmp -s "t0${i}.res" "t0${i}.out"
    #echo $?
    if [ $? == "1" ]
    then
        echo "Test $i Failed, expected:"
        cat "t0${i}.out" 
        echo
        echo "Received:"
        cat "t0${i}.res"
        echo

    else 
    	echo "Test $i Passed"
    fi
    rm "t0${i}.res"
done

rm "tema.cpp"
rm "./tema"

